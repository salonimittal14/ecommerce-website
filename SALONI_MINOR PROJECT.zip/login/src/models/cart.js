const mongoose =require("mongoose");

const customersSchema=new mongoose.Schema({
    caName:  {
        type:String,
        required:true
    },
    ctag:{
        type:String,
        required:true,
        unique:true
    },
    cprice:{
        type:Number,
        required:true
    },
    cincart:{
        type:Number,
        required:true


    },
    


})

const Cart=new mongoose.model("Cart",customersSchema);

module.exports=Cart;