let carts = document.querySelectorAll('.add-cart');
console.log("in main js")
let products = [
    {
        name: 'Red shirt',
        tag: 'flower print',
        price: 500,
        inCart: 0,
        image: '/image/image1.jpg'
    },
    {
        name: 'Blue shirt',
        tag: 'Line print',
        price: 600,
        inCart: 0,
        image: '/image/img2.jpg'
    },
    {
        name: 'Printed shirt',
        tag: 'Plain',
        price: 800,
        inCart: 0,
        image:'/image/img3.jpg'
    },
    {
        name: 'Sea design shirt',
        tag: 'New Print',
        price: 1000,
        inCart: 0,
        image:'/image/img4.jpg'
    },
    {
        name: 'Diamond texture shirt',
        tag: 'simple print',
        price: 1500,
        inCart: 0,
        image: '/image/img5.jpg'
    },
    {
        name: 'Big boxes print shirt',
        tag: 'check print',
        price: 1280,
        inCart: 0,
        image: '/image/img6.jpg'
    },
    {
        name: 'Feathers plazo',
        tag: 'Plazo',
        price: 350,
        inCart: 0,
        image:'/image/img7.jpg'
    },
    {
        name: 'Lining crop top',
        tag: 'crop',
        price: 299,
        inCart: 0,
        image:'/image/img8.jpg'
    }

];

for (let i = 0; i < carts.length; i++) {
    carts[i].addEventListener('click', () => {
        cartNumbers(products[i]);
        totalCost(products[i]);

    })
}

function onLoadCartNumbers() {
    let productNumbers = localStorage.getItem('cartNumbers');
    if (productNumbers) {
        let a = document.querySelector('.cart span')
        if (a)
            a.textContent = productNumbers;
    }
}

function cartNumbers(products) {
    console.log("The product clicked is", products);
    let productNumbers = localStorage.getItem('cartNumbers');
    productNumbers = parseInt(productNumbers);
    if (productNumbers) {
        localStorage.setItem('cartNumbers', productNumbers + 1);
        document.querySelector('.cart span').textContent = productNumbers + 1;
    } else {
        localStorage.setItem('cartNumbers', 1);
        document.querySelector('.cart span').textContent = 1;
    }
}
function cartNumbers(product) {
    let productNumbers = localStorage.getItem("cartNumbers");
    productNumbers = parseInt(productNumbers);
    if (productNumbers) {
        localStorage.setItem("cartNumbers", productNumbers + 1);
        document.querySelector(".cart span").textContent = productNumbers + 1;
    } else {
        localStorage.setItem("cartNumbers", 1);
        document.querySelector(".cart span").textContent = 1;
    }
    setItems(product);
}

function setItems(product) {
    let cartItems = localStorage.getItem("productsInCart");
    cartItems = JSON.parse(cartItems);
    if (cartItems != null) {
        if (cartItems[product.tag] == undefined) {
            cartItems = {
                ...cartItems,
                [product.tag]: product,
            };
        }
        cartItems[product.tag].inCart += 1;
    } else {
        product.inCart = 1;
        cartItems = {
            [product.tag]: product,
        };
    }
    localStorage.setItem("productsInCart", JSON.stringify(cartItems));
}

function totalCost(product) {
    let cartCost = localStorage.getItem("totalCost");
    console.log("My cartCost is", cartCost);
    console.log(typeof cartCost);
    if (cartCost != null) {
        cartCost = parseInt(cartCost);
        localStorage.setItem("totalCost", cartCost + product.price);
    } else {
        localStorage.setItem("totalCost", product.price);
    }
}
function changeQty(index, e) {
    console.log("in change qty ==>", index, e)

    let cartItems = localStorage.getItem("productsInCart");
    cartItems = JSON.parse(cartItems);

    let cart = Object.values(cartItems)
    cart[index].inCart = parseInt(e.value)
    const obj = {};

    for (const key of cart) {
        obj[key.tag] = key;
    }
    localStorage.setItem("productsInCart", JSON.stringify(obj));
    window.location.href = '/cart'
    console.log("carts ==>> ", obj)


    // cartItems[tag].inCart = parseInt(e.value);

    // localStorage.setItem("productsInCart", JSON.stringify(getCart));

}

function removeitemfromCart(index) {
    let cartItems = localStorage.getItem("productsInCart");
    cartItems = JSON.parse(cartItems);

    let cart = Object.values(cartItems)
    cart.splice(index, 1);
    const obj = {};

    for (const key of cart) {
        obj[key.tag] = key;
    }
    localStorage.setItem("productsInCart", JSON.stringify(obj));
    window.location.href = '/cart'

}

function displaycart() {
    console.log('in display cart ===>')
    let cartItems = localStorage.getItem("productsInCart");
    cartItems = JSON.parse(cartItems);
    let productContainer = document.querySelector(".cartTable");
    console.log("prod,", productContainer)
    let cartCost = localStorage.getItem("totalCost");

    console.log("cartItems");
    if (cartItems && productContainer) {
        (productContainer.innerHTML = "")
        let cart2 = Object.values(cartItems)

        cart2.map((item, index) => {
            console.log("items ===>>", item)
            productContainer.innerHTML += `
                <tr>
                <td><a href="#" onclick=removeitemfromCart(${index}) ><i class="fa fa-times-circle"></i></a></td>
                <td><img src=${item.image && item.image} alt=""> </td>
                <td>${item.name}</td>
                <td>&#8377  ${item.price}</td>
                <td><input type="number" value=${item.inCart} onclick=changeQty(${index},this)  ></td>
                <td>&#8377 ${item.inCart * item.price}</td>
            </tr>`
        });

        let totalBox = document.querySelector('#finalTotal')
        let prize = cart2.reduce((previousValue, currentValue) => {
            console.log("prev", previousValue, currentValue);
            return previousValue + (currentValue.inCart * currentValue.price);
        }, 0);

        console.log(prize);

        totalBox.innerHTML = `<tr>
        <td>Cart Subtotal</td>
        <td>&#8377 ${prize}</td>
    </tr>
    <tr>
        <td>Shipping</td>
        <td>Free</td>
    </tr>
    <tr>
        <td><strong>Total</strong></td>
        <td><strong>&#8377 ${prize}</strong></td>
    </tr>`

    }
}
onLoadCartNumbers();
displaycart();